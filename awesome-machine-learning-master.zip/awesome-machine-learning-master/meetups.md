The following is a list of free-to-attend meetups and local events on Machine Learning

- [India](#india)
    -   [Bangalore](#bangalore)
- [Brazil](#india)
    -   [São Paulo](#saopaulo)
<a name="india"></a>
## India

<a name="bangalore"></a>
### Bangalore
* [Bangalore Machine Learning Meetup (BangML)](https://www.meetup.com/BangML/)

<a name="brazil"></a>
## Brazil

<a name="saopaulo"></a>
### São Paulo
* [AI Brasil](https://www.meetup.com/pt-BR/ai-brasil/)
